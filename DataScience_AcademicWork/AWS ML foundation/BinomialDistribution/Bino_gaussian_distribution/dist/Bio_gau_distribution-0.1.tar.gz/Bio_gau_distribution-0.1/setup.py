from setuptools import setup

setup(name='Bio_gau_distribution',
      version='0.1',
      description='Gaussian and Bionomial distributions',
      packages= ['Bio_gau_distribution'],
      author = 'Moiz Khan',
      author_email= 'smartmoeez@gmail.com',
      zip_safe=False)
